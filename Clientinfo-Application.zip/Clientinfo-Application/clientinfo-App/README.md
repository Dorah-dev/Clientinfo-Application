---
Clientinfo is an application to capture and maintain client information(web or desktop).  
The clients name, gender and basic details must be captured.  
In addition the system  allows you  to capture of multiple addresses and contact information, each to be defined by type (I.E. Residential Address, Work Address, Postal Address, Cell Number, Work Number etc.)
Allow for large volumes of client’s.
