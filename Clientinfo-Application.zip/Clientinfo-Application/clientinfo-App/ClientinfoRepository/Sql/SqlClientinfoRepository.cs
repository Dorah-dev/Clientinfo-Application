﻿using Clientinfo.Models;
using Microsoft.EntityFrameworkCore;

namespace Clientinfo.Repository.Sql
{
    /// <summary>
    /// Contains methods for interacting with the app backend using 
    /// SQL via Entity Framework Core 2.0. 
    /// </summary>
    public class SqlClientinfoRepository : IClientinfoRepository
    {
        private readonly DbContextOptions<ClientinfoContext> _dbOptions; 

        public SqlClientinfoRepository(DbContextOptionsBuilder<ClientinfoContext> 
            dbOptionsBuilder)
        {
            _dbOptions = dbOptionsBuilder.Options;
            using (var db = new ClientinfoContext(_dbOptions))
            {
                db.Database.EnsureCreated(); 
            }
        }

        public ICustomerRepository Customers => new SqlCustomerRepository(
            new ClientinfoContext(_dbOptions));

        public IOrderRepository Orders => new SqlOrderRepository(
            new ClientinfoContext(_dbOptions));

        public IProductRepository Products => new SqlProductRepository(
            new ClientinfoContext(_dbOptions));
    }
}
