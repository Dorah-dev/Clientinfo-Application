﻿using Clientinfo.Models;
using Microsoft.EntityFrameworkCore;

namespace Clientinfo.Repository.Sql
{
    /// <summary>
    /// Entity Framework Core DbContext for Clientinfo.
    /// </summary>
    public class ClientinfoContext : DbContext
    {
        /// <summary>
        /// Creates a new Clientinfo DbContext.
        /// </summary>
        public ClientinfoContext(DbContextOptions<ClientinfoContext> options) : base(options)
        { }

        /// <summary>
        /// Gets the customers DbSet.
        /// </summary>
        public DbSet<Customer> Customers { get; set; }

        /// <summary>
        /// Gets the orders DbSet.
        /// </summary>
        public DbSet<Order> Orders { get; set; }

        /// <summary>
        /// Gets the products DbSet.
        /// </summary>
        public DbSet<Product> Products { get; set; }

        /// <summary>
        /// Gets the line items DbSet.
        /// </summary>
        public DbSet<LineItem> LineItems { get; set; }
    }
}
