﻿using Clientinfo.Models;

namespace Clientinfo.Repository.Rest
{
    /// <summary>
    /// Contains methods for interacting with the app backend using REST. 
    /// </summary>
    public class RestClientinfoRepository : IClientinfoRepository
    {
        private readonly string _url; 

        public RestClientinfoRepository(string url)
        {
            _url = url; 
        }

        public ICustomerRepository Customers => new RestCustomerRepository(_url); 

        public IOrderRepository Orders => new RestOrderRepository(_url);

        public IProductRepository Products => new RestProductRepository(_url); 
    }
}
